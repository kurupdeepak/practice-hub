package com.mytracker.usermanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MytrackerUsermanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
